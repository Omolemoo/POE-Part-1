﻿using System;

namespace RecipeApp
{
    class Ingredient
    {
        public string Name { get; set; }
        public double Quantity { get; set; }
        public string Unit { get; set; }
    }

    class Recipe
    {
        public string Name { get; set; }
        public Ingredient[] Ingredients { get; set; }
        public string[] Steps { get; set; }

        public Recipe(string name, int numIngredients, int numSteps)
        {
            Name = name;
            Ingredients = new Ingredient[numIngredients];
            Steps = new string[numSteps];
        }

        public void DisplayRecipe()
        {
            Console.WriteLine($"Recipe: {Name}");
            Console.WriteLine("Ingredients:");
            foreach (var ingredient in Ingredients)
            {
                Console.WriteLine($"{ingredient.Quantity} {ingredient.Unit} of {ingredient.Name}");
            }
            Console.WriteLine("Steps:");
            for (int i = 0; i < Steps.Length; i++)
            {
                Console.WriteLine($"{i + 1}. {Steps[i]}");
            }
        }

        public void ScaleRecipe(double factor)
        {
            foreach (var ingredient in Ingredients)
            {
                ingredient.Quantity *= factor;
            }
        }

        public void ResetQuantities()
        {
            // Reset quantities to original values
            // For simplicity, we'll assume original quantities are 1
            foreach (var ingredient in Ingredients)
            {
                ingredient.Quantity = 1;
            }
        }

        public void ClearRecipe()
        {
            // Clear recipe data
            Name = null;
            Ingredients = null;
            Steps = null;
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            // Initialize recipe
            Recipe recipe = InitializeRecipe();

            // Display recipe
            recipe.DisplayRecipe();

            // Scale recipe
            recipe.ScaleRecipe(2); // Scale by a factor of 2
            Console.WriteLine("\nScaled Recipe:");
            recipe.DisplayRecipe();

            // Reset quantities
            recipe.ResetQuantities();
            Console.WriteLine("\nOriginal Recipe:");
            recipe.DisplayRecipe();

            // Clear recipe data
            recipe.ClearRecipe();
        }

        static Recipe InitializeRecipe()
        {
            Console.Write("Enter recipe name: ");
            string name = Console.ReadLine();

            Console.Write("Enter number of ingredients: ");
            int numIngredients = int.Parse(Console.ReadLine());

            Console.Write("Enter number of steps: ");
            int numSteps = int.Parse(Console.ReadLine());

            Recipe recipe = new Recipe(name, numIngredients, numSteps);

            // Input ingredients
            for (int i = 0; i < numIngredients; i++)
            {
                Console.WriteLine($"Enter details for ingredient {i + 1}:");
                Console.Write("Name: ");
                string ingredientName = Console.ReadLine();
                Console.Write("Quantity: ");
                double quantity = double.Parse(Console.ReadLine());
                Console.Write("Unit: ");
                string unit = Console.ReadLine();

                recipe.Ingredients[i] = new Ingredient { Name = ingredientName, Quantity = quantity, Unit = unit };
            }

            // Input steps
            for (int i = 0; i < numSteps; i++)
            {
                Console.WriteLine($"Enter step {i + 1}:");
                recipe.Steps[i] = Console.ReadLine();
            }

            return recipe;
        }
    }
}
